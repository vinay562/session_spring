package productApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class productApplication {
public static void main(String[] args) {
		
		SpringApplication.run(productApplication.class, args);
		
	}

}
